<?php
$host = "sql209.infinityfree.com";
$db   = "if0_41824822_phptest";
$user = "if0_41824822";
$pass = "2OpCizX05r";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("DB Connection Failed: " . $e->getMessage());
}
?>